$(function () {
    //user login function
    $('#loginform button').click(function () {
        var user = $('input[name="user"]').val();
        var password = $('input[name="password"]').val();

        if (!user) {
            $('#errordetails').empty().append('Username is Required!');
        } else if (!password) {
            $('#errordetails').empty().append('Password is Required!');
        } else {
            $('#errordetails').empty();
            $.ajax({
                url: $('body').data('site-url') + 'login/validate_user',
                type: 'post',
                data: {
                    user: user,
                    password: password
                },
                success: function (res) {
                    if (res == 1) {
                        window.location.href = $('body').data('site-url') + 'students';
                    } else {
                        $('#errordetails').empty().append('Invalid Username or Password!');
                    }
                },
                error: function (error) {
                    alert(JSON.stringify(error));
                }
            });
        }

    });

//creating new user function
    $('#signupform button').click(function () {
        var user = $('input[name="user"]').val();
        var password = $('input[name="password"]').val();

        if (!user) {
            $('#errordetails').empty().append('Username is Required!');
        } else if (!password) {
            $('#errordetails').empty().append('Password is Required!');
        } else {
            $('#errordetails').empty();
            $.ajax({
                url: $('body').data('site-url') + 'login/create_user',
                type: 'post',
                data: {
                    user: user,
                    password: password
                },
                success: function (res) {
                    if (res == -1) {
                        $('#errordetails').empty().append('User already existed!');
                    } else if (res > 0) {
                        swal({
                            title: "Creation",
                            text: "User created Successfully!",
                            type: "success",
                            closeOnConfirm: true
                        }, function () {
                            window.location.href = $('body').data('site-url') + 'login';
                        });
                    } else {
                        $('#errordetails').empty().append('Error in creation!');
                    }
                },
                error: function (error) {
                    alert(JSON.stringify(error));
                }
            });
        }

    });

});
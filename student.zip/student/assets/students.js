
//mobile no validation with 10 digit
$(document).on("keypress", ".mobile-no", function (e) {
    if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        return false;
    } else {
        var value = $(this).val();
        if (value.length > 9) {
            return false;
        }
    }
});

//allow only digits and backspace only
$(document).on("keypress", ".check-digits", function (e) {
    if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
        return false;
    }
});

//report card marks calculations
$(document).on('keyup', '.obtained_marks', function (e) {
    var marks = parseFloat($(this).val());
    var tr = $(this).closest('tr');
    var total_marks = parseFloat(tr.find('td:eq(3)').text());
    if (marks <= total_marks) {
        $('.grade-details-table .marks-range').each(function () {
            var closest_tr = $(this).closest('tr');
            var marks_range = closest_tr.find('td:eq(0)').text();
            var marks_array = marks_range.split('-');

            var marks_form = parseInt(marks_array[0]);
            var marks_to = parseInt(marks_array[1]);
            if ((marks_form <= marks) && (marks <= marks_to)) {
                var marks_grade = closest_tr.find('td:eq(1)').text();
                tr.find('.grade_marks').empty().append(marks_grade);
                total_obtained_marks();
            }
        });
    } else {
        $(this).val('');
        tr.find('.grade_marks').empty().append('F');
    }

});

//marks calculation function
function total_obtained_marks() {
    var obtained_marks = 0;
    $('.report-table tbody tr').each(function () {
        var marks = $(this).closest('tr').find('.obtained_marks').val();
        marks = (marks) ? parseFloat(marks) : 0;
        obtained_marks = obtained_marks + marks;
    });
    $('.report-table tfoot .total-obtained-marks').empty().append(obtained_marks);
    var totalmarks = $('.report-table tfoot .totalmarks').text();
    totalmarks = parseFloat(totalmarks);

    var percentage = (obtained_marks / totalmarks) * 100;
    percentage = percentage.toFixed(2);
    var reportclass = '';
    if (percentage < 40) {
        reportclass = 'FAIL';
    } else if ((percentage >= 40) && (percentage < 50)) {
        reportclass = 'THIRD';
    } else if ((percentage >= 50) && (percentage < 60)) {
        reportclass = 'SECOND';
    } else {
        reportclass = 'FIRST';
    }

    $('.report-table tbody tr').each(function () {
        var grade = $(this).closest('tr').find('.grade_marks').text();
        if (grade == 'F') {
            reportclass = 'FAIL';
        }
    });

    $('.report-table tfoot .report-final-class').empty().append(reportclass);
}


//new student saving function
$(document).on('click', '.saveformdata', function () {
    var url = $(this).data('url');
    var redirect_url = $(this).data('redirect_url');
    var newForm = $('#form_data').parsley();
    newForm.validate();
    if (newForm.isValid()) {
        var report_details_array = [];
        $('.report-table tbody tr').each(function () {
            var report_details = {
                subject_id: $(this).attr('id'),
                obtained_marks: $(this).find('.obtained_marks').val(),
                grade: $(this).find('.grade_marks').text()
            };
            report_details_array.push(report_details);
        });

        var formdata = new FormData();
        formdata.append('name', $('#name').val());
        formdata.append('parent_name', $('#parent_name').val());
        formdata.append('parent_email', $('#parent_email').val());
        formdata.append('mobile', $('#mobile').val());
        formdata.append('department', $('#department').val());
        formdata.append('dob', $('#dob').val());
        formdata.append('img', $('#img')[0].files[0]);
        formdata.append('total_obtained_marks', $('.report-table tfoot .total-obtained-marks').text());
        formdata.append('total_marks', $('.report-table tfoot .totalmarks').text());
        formdata.append('result_class', $('.report-table tfoot .report-final-class').text());
        formdata.append('report_details_array', JSON.stringify(report_details_array));

        $.ajax({
            type: "post",
            url: url,
            data: formdata,
            mimeType: 'multipart/form-data',
            contentType: false,
            processData: false,
            success: function (response) {
//                alert(response);
                if (response) {
                    swal({
                        title: "Creation",
                        text: "Student Details saved Successfully!",
                        type: "success",
                        closeOnConfirm: true
                    }, function () {
                        window.location.href = redirect_url;
                    });
                }
            },
            error: function (error) {
                alert(JSON.stringify(error));
            }
        });
    }
});

//student update function
$(document).on('click', '.updateformdata', function () {
    var url = $(this).data('url');
    var redirect_url = $(this).data('redirect_url');
    var id = $(this).data('id');
    var newForm = $('#form_data').parsley();
    newForm.validate();
    if (newForm.isValid()) {
        var report_details_array = [];
        $('.report-table tbody tr').each(function () {
            var report_details = {
                subject_id: $(this).attr('id'),
                id: $(this).data('report_id'),
                obtained_marks: $(this).find('.obtained_marks').val(),
                grade: $(this).find('.grade_marks').text()
            };
            report_details_array.push(report_details);
        });

        var formdata = new FormData();
        formdata.append('id', id);
        formdata.append('name', $('#name').val());
        formdata.append('parent_name', $('#parent_name').val());
        formdata.append('parent_email', $('#parent_email').val());
        formdata.append('mobile', $('#mobile').val());
        formdata.append('department', $('#department').val());
        formdata.append('dob', $('#dob').val());
        formdata.append('img', $('#img')[0].files[0]);
        formdata.append('total_obtained_marks', $('.report-table tfoot .total-obtained-marks').text());
        formdata.append('total_marks', $('.report-table tfoot .totalmarks').text());
        formdata.append('result_class', $('.report-table tfoot .report-final-class').text());
        formdata.append('report_details_array', JSON.stringify(report_details_array));

        $.ajax({
            type: "post",
            url: url,
            data: formdata,
            mimeType: 'multipart/form-data',
            contentType: false,
            processData: false,
            success: function (response) {
//                alert(response);
                if (response) {
                    swal({
                        title: "Updation",
                        text: "Student Details Updated Successfully!",
                        type: "success",
                        closeOnConfirm: true
                    }, function () {
                        window.location.href = redirect_url;
                    });
                }
            },
            error: function (error) {
                alert(JSON.stringify(error));
            }
        });
    }

});


//student data delete function
$(document).on('click', '.table .btn-delete', function () {
    var current = $(this);
    swal({
        title: "Are you sure?",
        text: "You want to delete this record!",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Yes",
        cancelButtonText: "Cancel",
        closeOnConfirm: false,
        closeOnCancel: false
    },
            function (isConfirm) {
                if (isConfirm) {
                    var id = current.closest('tr').attr('id');
                    $.ajax({
                        url: current.data('url'),
                        method: 'post',
                        data: {
                            id: id
                        },
                        success: function (res) {
                            if (res) {
                                swal({
                                    title: "Successfully",
                                    text: 'Record deleted Successfully',
                                    type: "success",
                                    closeOnConfirm: true
                                }, function () {
                                    window.location.href = current.data('redirect_url');
                                });
                            } else {
                                swal("Warning", "Error in deletion", "error");
                            }
                        },
                        error: function (res) {
                            alert(JSON.stringify(res));
                        }
                    });
                } else {
                    swal("Cancelled", "Your Record not deleted!", "error");
                }
            });

});
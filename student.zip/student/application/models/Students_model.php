<?php

class Students_model extends My_Model {

   public function __construct() {
        parent::__construct();
        $this->table = "students";
    }
}

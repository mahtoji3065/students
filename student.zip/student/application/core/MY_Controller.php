<?php

class MY_Controller extends CI_Controller {

    function __construct() {
        parent::__construct();
        $controlerAccessClass = $this->router->class;
        if($controlerAccessClass != 'login'){
            $sessionData = $this->session->userdata;
            if(isset($sessionData['user_id'])){
                
            }else{
                redirect('login');
            }
        }
    }

}

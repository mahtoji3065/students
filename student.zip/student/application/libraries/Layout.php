<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * class Layout
 *
 * @package application/libraries
 */
class Layout {

    /**
     * Hold the CI instance.
     */
    private $CI;

    /**
     * Hold the HTML doctype. Default to HTML5 document.
     * @var string
     */
    private $_doctype = 'html5';

    /**
     * Hold the meta title.
     * @var string
     */
    private $_meta_title = '';

    /**
     * Hold any meta data (keywords, description etc ...).
     * @var array
     */
    private $_meta_data = array();

    /**
     * Hold the CSS of the layout.
     * @var array
     */
    private $_css = array();

    /**
     * Hold the JavaScript of the layout.
     * @var array
     */
    private $_js = array();

    function __construct() {
        $this->CI = & get_instance();

        // load required stuff
        $this->CI->load->helper('html');
    }

    /**
     * Set the HTML doctype.
     * @param 	string		$doctype
     */
    public function set_doctype($doctype) {
        $this->_doctype = $doctype;
    }

    /**
     * Set a new meta title.
     * @param 	string		$title
     */
    public function set_meta_title($title = '') {
        $this->_meta_title = $title;
    }

    /**
     * Set meta data.
     * @param 	array		$meta
     */
    public function set_meta_data($meta = array()) {
        $this->_meta_data = $meta;
    }

    /**
     * Set CSS.
     *
     * @param 	string 	$src (link source or css rules)
     * @param 	string 	$type (link or embed)
     * @param 	string 	$media (media type: all, screen, print, etc ... )
     * @return 	object
     */
    public function add_css($style, $type = 'link', $media = 'all') {
        $this->_css[] = array(
            'src' => $style,
            'type' => $type,
            'media' => $media,
        );

        return $this;
    }

    /**
     * Set JavaScript.
     *
     * @param 	string 	$src (link source or script code)
     * @param 	string 	$type (link or embed)
     * @return 	object
     */
    public function add_js($script, $type = 'link') {
        $this->_js[] = array(
            'src' => $script,
            'type' => $type,
        );

        return $this;
    }

    /**
     * Return the doctype
     * @return string
     */
    private function _get_doctype() {
        return doctype($this->_doctype) . PHP_EOL;
    }

    /**
     * Return the meta title.
     * @return 	string
     */
    private function _get_meta_title() {
        if (empty($this->_meta_title)) {
            return $this->_meta_title;
        }

        $this->CI->load->helper('inflector');
        return humanize($this->_meta_title);
    }

    /**
     * Return the meta data
     * @return string
     */
    private function _get_meta_data() {
        return meta($this->_meta_data);
    }

    /**
     * Return all required CSS for the layout.
     * @return 	string
     */
    private function _get_css() {

        $output = '';

        if (empty($this->_css)) {
            return $output;
        }

        foreach ($this->_css as $style) {

            switch ($style['type']) {
                case 'link':
                    if (preg_match('@^https?:\/\/@', $style['src'])) {
                        $src = $style['src'];
                    } else {
                        $src = $this->CI->config->base_url($style['src']);
                    }

                    $output .= link_tag($src, 'stylesheet', 'text/css', '', $style['media']) . PHP_EOL;
                    break;

                case 'embed':
                    $output .= '<style type="text/css" media="' . $style['media'] . '">' . PHP_EOL;
                    $output .= $style['src'] . PHP_EOL;
                    $output .= '</style>' . PHP_EOL;
                    break;

                default:
                    show_error('Error occured with a CSS file.');
                    break;
            }
        }

        return $output;
    }

    /**
     * Return all required JavaScript for the layout.
     * @return 	string
     */
    private function _get_js() {

        $output = '';

        if (empty($this->_js)) {
            return $output;
        }

        foreach ($this->_js as $script) {

            switch ($script['type']) {
                case 'link':
                    // is an external file
                    if (preg_match('@^https?:\/\/@', $script['src'])) {
                        $src = $script['src'];
                    } // is an attached file
                    else {
                        $src = $this->CI->config->base_url($script['src']);
                    }

                    $output .= '<script type="text/javascript" src="' . $src . ' "></script>' . PHP_EOL;
                    break;

                case 'embed':
                    $output .= '<script type="text/javascript">' . PHP_EOL;
                    $output .= $script['src'] . PHP_EOL;
                    $output .= '</script>' . PHP_EOL;
                    break;

                default:
                    show_error('Error occured with JavaScript file.');
                    break;
            }
        }

        return $output;
    }

    /**
     * Render a view. 
     * 1st parameter is the main view. This view typically you would store it
     * in a 'includes' folder to keep it separate from any partial/sub views.
     * 2nd parameter is an array that holds the partial/sub views.
     *
     * REMEMBER: if the views are in folders you have to pass and the folder too!
     *
     * 3rd parameter is an array of data from database etc and 4th parameter is a boolean
     * that checks whether to include on the view and layout data.
     *
     * @param 	string 		$view  
     * @param 	array 		$partials 
     * @param 	array 		$data 
     * @param 	bool 		$default	
     */
    public function view($view = '', $partials = array(), $data = array(), $default = true) {

        // check for layout partials and add them to the main layout view
        if (is_array($partials) && count($partials)) {
            foreach ($partials as $key => $value) {
                $data[$key] = $this->CI->load->view($value, $data, true);
            }
        }

        if ($default === true) {
            // pass various layout data, to the main view
            $data['doctype'] = $this->_get_doctype();
            $data['meta_title'] = $this->_get_meta_title();
            $data['meta_data'] = $this->_get_meta_data();
            $data['css'] = $this->_get_css();
            $data['js'] = $this->_get_js();
        }

        // render the view
        $this->CI->load->view($view, $data);
    }

}

/* End of file Layout.php */
/* Location: ./application/libraries/layout.php */
<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Login_model', 'login');
        $this->layout->add_js('assets/login.js');
    }

    public function index() {
        $data['title'] = 'Students';
        $partials['contents'] = "login/index";
        $this->layout->view("include/default", $partials, $data);
    }

    public function validate_user() {
        $data = $this->input->post();
        $data['status'] = '1';
        $result = $this->login->where($data)->get();
        if (!empty($result)) {
            $this->session->set_userdata('user_id', $result->id);
            echo '1';
        } else {
            echo '0';
        }
    }

    public function create_user() {
        $data = $this->input->post();
        $result = $this->login->where($data)->count();
        if ($result) {
            echo -1;
        } else {
            $data['status'] = '1';
            $data['created_by'] = '1';
            $data['created_at'] = date("Y-m-d H:i:s");
            echo $this->login->insert($data);
        }
    }

    public function sign_up() {
        $data['title'] = 'Students';
        $partials['contents'] = "login/sign_up";
        $this->layout->view("include/default", $partials, $data);
    }

    public function logout() {
        $this->session->unset_userdata('user_id');
        redirect();
    }

}

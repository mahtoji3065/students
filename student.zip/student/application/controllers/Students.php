<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Students extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Students_model', 'students');
        $this->load->model('Subject_model', 'subject');
        $this->load->model('Report_card_model', 'report_card');
        $this->layout->add_js('assets/students.js');
    }

    public function index() {
        $data['title'] = 'Students';
        $data['controller'] = $this;
        $partials['contents'] = "students/index";
        $this->layout->view("include/default", $partials, $data);
    }

    public function ajax_load() {
        $data['result'] = $this->students->where(array('status'=>'1'))->get_all();
        echo $this->load->view("students/ajax_load", $data, TRUE);
    }

    public function new_form() {
        $data['title'] = 'students';
        $data['subject_details'] = $this->subject->fields('id,name,pass_marks,total_marks')->where(array('status' => '1'))->get_all();
        $partials['contents'] = "students/new_form";
        $this->layout->view("include/default", $partials, $data);
    }

    public function save_new() {
        $studentDetails = array(
            'name' => $this->input->post('name'),
            'parent_name' => $this->input->post('parent_name'),
            'parent_email' => $this->input->post('parent_email'),
            'mobile' => $this->input->post('mobile'),
            'department' => $this->input->post('department'),
            'dob' => $this->input->post('dob'),
            'total_obtained_marks' => $this->input->post('total_obtained_marks'),
            'total_marks' => $this->input->post('total_marks'),
            'result_class' => $this->input->post('result_class'),
            'status' => '1',
            'created_by' => $this->session->userdata('user_id'),
            'created_at' => date("Y-m-d H:i:s"),
        );

        $img = $_FILES['img'];
        if (!empty($img)) {
            $img_dir = STUDENT_IMG . $img["name"];
            if (move_uploaded_file($img["tmp_name"], $img_dir)) {
                $studentDetails['img'] = $img["name"];
            }
        }

        $student_id = $this->students->insert($studentDetails);
        if ($student_id) {
            $report_details_array = json_decode($this->input->post('report_details_array'));
            if (!empty($report_details_array)) {
                foreach ($report_details_array as $row) {
                    $row->student_id = $student_id;
                    $row->status = '1';
                    $row->created_by = $this->session->userdata('user_id');
                    $row->created_at = date("Y-m-d H:i:s");
                    $this->report_card->insert($row);
                }
                echo $student_id;
            }
        }
    }

    public function edit_form($id) {
        $data['title'] = 'students';
        $student_query = 'SELECT * FROM students WHERE status="1" AND id="' . $id . '"';
        $data['student_details'] = $this->db->query($student_query)->result();
        $subject_query = 'SELECT s.id,s.name,s.pass_marks,s.total_marks,rc.obtained_marks,rc.grade,rc.id AS report_id FROM subject AS s '
                . ' LEFT JOIN report_card AS rc ON rc.subject_id = s.id '
                . ' WHERE s.status="1" AND rc.student_id="' . $id . '"';
        $data['subject_details'] = $this->db->query($subject_query)->result();
        $partials['contents'] = "students/edit_form";
        $this->layout->view("include/default", $partials, $data);
    }

    public function save_edit() {
        $student_id = $this->input->post('id');
        $studentDetails = array(
            'name' => $this->input->post('name'),
            'parent_name' => $this->input->post('parent_name'),
            'parent_email' => $this->input->post('parent_email'),
            'mobile' => $this->input->post('mobile'),
            'department' => $this->input->post('department'),
            'dob' => $this->input->post('dob'),
            'total_obtained_marks' => $this->input->post('total_obtained_marks'),
            'total_marks' => $this->input->post('total_marks'),
            'result_class' => $this->input->post('result_class'),
            'updated_by' => $this->session->userdata('user_id'),
            'updated_at' => date("Y-m-d H:i:s"),
        );
        if (!empty($_FILES)) {
            $img = $_FILES['img'];
            $img_dir = STUDENT_IMG . $img["name"];
            if (move_uploaded_file($img["tmp_name"], $img_dir)) {
                $studentDetails['img'] = $img["name"];
            }
        }
        $student_updated = $this->students->update($studentDetails, $student_id);
        if ($student_updated) {
            $report_details_array = json_decode($this->input->post('report_details_array'));
            if (!empty($report_details_array)) {
                foreach ($report_details_array as $row) {
                    $row->updated_by = $this->session->userdata('user_id');
                    $row->updated_at = date("Y-m-d H:i:s");
                    $this->report_card->update($row, $row->id);
                }
                echo $student_updated;
            }
        }

    }

    public function send_report($id) {
        $student_query = 'SELECT total_obtained_marks,result_class,parent_email,name FROM students WHERE status="1" AND id="' . $id . '"';
        $data['student_details'] = $this->db->query($student_query)->result();

        $subject_query = 'SELECT s.id,s.name,s.pass_marks,s.total_marks,rc.obtained_marks,rc.grade,rc.id AS report_id FROM subject AS s '
                . ' LEFT JOIN report_card AS rc ON rc.subject_id = s.id '
                . ' WHERE s.status="1" AND rc.student_id="' . $id . '"';
        $data['subject_details'] = $this->db->query($subject_query)->result();


        $this->load->library('email');

        $body = $this->load->view('students/mail_report', $data, TRUE);
        $subject = 'Report Card';
        $this->email->from('mahtoji3065@gmail.com',$data['student_details'][0]->name)->to($data['student_details'][0]->parent_email)->subject($subject)->message($body)->send();
        redirect('students');
    }

    public function delete_record(){
        $student_id = $this->input->post('id');
        $deleted_data = array(
            'status' => '2',
            'updated_by' => $this->session->userdata('user_id'),
            'updated_at' => date("Y-m-d H:i:s"),
        );
        $student_updated = $this->students->update($deleted_data, $student_id);
        if($student_updated){
            echo $this->report_card->where(array('student_id'=>$student_id))->update($deleted_data);
        }
    }
    
}

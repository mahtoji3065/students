
<div class="col-md-12 table-responsive">
    <table class="table table-condensed">
        <thead>
            <tr>
                <th>S.No.</th>
                <th>Student-Name</th>
                <th>Parent-Name</th>
                <th>Parent-Email</th>
                <th>Mobile</th>
                <th>D.O.B</th>
                <th>Department</th>
                <th>Mail</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (!empty($result)) {
                $count = 1;
                foreach ($result as $row) {
                    ?>
                    <tr id="<?php echo $row->id; ?>">
                        <td><?php echo $count++; ?></td>
                        <td><?php echo ucwords($row->name); ?></td>            
                        <td><?php echo ucwords($row->parent_name); ?></td>            
                        <td><?php echo $row->parent_email; ?></td>
                        <td><?php echo $row->mobile; ?></td>                            
                        <td><?php echo $row->dob; ?></td>
                        <td><?php echo $row->department; ?></td>
                        <td><a href="<?php echo site_url('students/send_report/') . $row->id; ?>" > <i class="fa fa-envelope"></i> </a></td>
                        <td>
                            <a class="btn btn-primary btn-xs" href="<?php echo site_url('students/edit_form/') . $row->id; ?>" > <i class="fa fa-pencil-square-o"></i> </a>

                            <span class="btn btn-danger btn-delete btn-xs"  data-redirect_url="<?php echo site_url('students'); ?>"
                                  data-url="<?php echo site_url('students/delete_record'); ?>" >
                                <i class="fa fa-trash"></i>
                            </span>
                        </td>
                    </tr>
                    <?php
                }
            } 
            ?>
        </tbody>
    </table>
</div>  

<script>
    $(function () {
        $('.table').DataTable();
    });
</script>

<div class="row">
    <a class="pull-right text-danger" href="<?php echo site_url('login/logout'); ?>">Logout</a>
</div>
<div class="col-md-12">
    <div class="panel panel-primary">
        <div class="panel-heading">
            <div class="row">
                <div class="col-md-6">
                    <h4><i class="fa fa-list"></i> <?php echo $title; ?> List</h4>
                </div>
                <div class="col-md-6">
                    <a class="btn btn-success pull-right" 
                       href="<?php echo site_url('students/new_form'); ?>"> <i class="fa fa-plus"></i> <?php echo $title; ?></a>
                </div>
            </div>
        </div>
        <div class="panel-body">
            <?php
            $controller->ajax_load();
            ?>
        </div>
    </div>
</div>
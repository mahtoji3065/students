<div class="col-md-12">
    <div class="panel panel-primary">
        <div class="panel-heading">
            <div class="row">
                <div class="col-md-6">
                    <h4> <strong><i class="fa fa-pencil-square-o"></i> New Student</strong></h4>
                </div>
                <div class="col-md-6">
                    <a class="btn btn-danger pull-right btn-sm" 
                       href="<?php echo site_url('students'); ?>"> <i class="fa fa-arrow-left"></i> Back</a>
                </div>
            </div>
        </div>
        <div class="panel-body">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="review-content-section">
                        <form id="form_data" data-parsley-validate="">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="name">Student Name <span class="text-danger">*</span></label>
                                        <input name="name" id="name" type="text" class="form-control"
                                               data-parsley-error-message="Student Name is Required."
                                               placeholder="Student Name..." required >
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="parent_name">Parent Name <span class="text-danger">*</span></label>
                                        <input name="parent_name" id="parent_name" type="text" class="form-control"
                                               data-parsley-error-message="Parent Name is Required."
                                               placeholder="Parent Name..." required >
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="parent_email" >Parent Email <span class="text-danger">*</span></label>
                                        <input name="parent_email" id="parent_email" type="email" class="form-control"
                                               data-parsley-error-message="Parent Email is Required."
                                               placeholder="Parent Email..." required >
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="mobile" >Mobile <span class="text-danger">*</span></label>
                                        <input name="mobile" id="mobile" type="text" class="form-control mobile-no"
                                               data-parsley-error-message="Mobile is Required."
                                               placeholder="Mobile..." required >
                                        <span class="mobile_error text-danger"></span>
                                    </div>
                                </div>
                            </div>
                            <hr />
                            <div class="row">                                    
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="department" >Department<span class="text-danger">*</span></label>
                                        <select name="department" id="department" required=""
                                                data-parsley-errors-container="#department-error" 
                                                data-parsley-error-message="Department is Required."
                                                class="form-control chosen-select">
                                            <option value="" selected="" disabled="" >Select Department</option>
                                            <option value="computer_science">Computer Science</option>
                                            <option value="social_scient">Social Science</option>
                                            <option value="mathematics">Mathematics</option>
                                        </select>
                                        <div id="department-error"></div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="dob" >Date of Birth<span class="text-danger">*</span></label>
                                        <input name="dob" id="dob" type="date" style="line-height: 20px;" value="<?php echo date('Y-m-d'); ?>"
                                               data-parsley-error-message="D.O.B is Required."
                                               class="form-control" placeholder="Date of Birth..." required >
                                    </div>
                                </div>                                
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="img" >Student Photo<span class="text-danger">*</span></label>
                                        <input name="img" id="img" type="file"
                                               data-parsley-error-message="Student Photo is Required."
                                               placeholder="Student Photo..." required >
                                    </div>
                                </div>                                
                            </div>
                            <hr />                           

                            <div class="row">
                                <div class="col-md-8">
                                    <div class="table-responsive" style="border: 1px solid lightgray; ">
                                        <table class="table report-table" style="margin-bottom: 0px;">
                                            <thead style="background: darkgray;">
                                                <tr>
                                                    <th>S.No.</th>
                                                    <th>Subject</th>
                                                    <th>Passing Marks</th>
                                                    <th>Total Marks</th>
                                                    <th>Obtained Marks</th>
                                                    <th>Grade</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $total_marks = 0;
                                                $total_passmarks = 0;
                                                if (!empty($subject_details)) {
                                                    $count = 1;
                                                    foreach ($subject_details as $row) {
                                                        $total_marks = $total_marks + $row->total_marks;
                                                        $total_passmarks = $total_passmarks + $row->pass_marks;
                                                        ?>
                                                        <tr id="<?php echo $row->id; ?>">
                                                            <td><?php echo $count++; ?></td>
                                                            <td><?php echo $row->name; ?></td>
                                                            <td><?php echo $row->pass_marks; ?></td>
                                                            <td><?php echo $row->total_marks; ?></td>
                                                            <td><input name="obtained_marks" type="text" class="form-control check-digits obtained_marks" placeholder="Obtained Marks..." required ></td>
                                                            <td><strong><span class="grade_marks"></span></strong></td>
                                                        </tr>
                                                        <?php
                                                    }
                                                }
                                                ?>                                           
                                            </tbody>
                                            <tfoot style="background: darkgray;">
                                                <tr>
                                                    <th colspan="2" style="text-align: right">Total</th>
                                                    <th class="total_passmarks"><?php echo $total_passmarks; ?></th>
                                                    <th class="totalmarks"><?php echo $total_marks; ?></th>
                                                    <th class="total-obtained-marks"></th>
                                                    <th class="report-final-class"></th>
                                                </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <table class="table table-bordered grade-details-table">
                                        <tr style="background: cadetblue;">
                                            <th colspan="2">Grade Details</th>
                                        </tr>
                                        <tr>
                                            <th>Marks</th>
                                            <th>Grade</th>
                                        </tr>
                                        <tr class="marks-range">
                                            <td>91-100</td>
                                            <td>A+</td>
                                        </tr>
                                        <tr class="marks-range">
                                            <td>81-90</td>
                                            <td>A</td>
                                        </tr>
                                        <tr class="marks-range">
                                            <td>71-80</td>
                                            <td>A-</td>
                                        </tr>
                                        <tr class="marks-range">
                                            <td>61-70</td>
                                            <td>B+</td>
                                        </tr>
                                        <tr class="marks-range">
                                            <td>51-60</td>
                                            <td>B</td>
                                        </tr>
                                        <tr class="marks-range">
                                            <td>40-50</td>
                                            <td>C</td>
                                        </tr>
                                        <tr class="marks-range">
                                            <td>0-39</td>
                                            <td>F</td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="col-md-2">
                                    <table class="table table-bordered class-details-table">
                                        <tr style="background: cornflowerblue;">
                                            <th colspan="2">Class Details</th>
                                        </tr>
                                        <tr>
                                            <th>%</th>
                                            <th>Class</th>
                                        </tr>
                                        <tr >
                                            <td>60%-100%</td>
                                            <td>FIRST</td>
                                        </tr>
                                        <tr >
                                            <td>50%-59%</td>
                                            <td>SECOND</td>
                                        </tr>
                                        <tr >
                                            <td>40%-49%</td>
                                            <td>THIRD</td>
                                        </tr>
                                        <tr >
                                            <td>0%-39%</td>
                                            <td>FAIL</td>
                                        </tr>                                         
                                    </table>
                                </div>
                            </div>                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="panel-footer">
            <div class="row">
                <div class="text-center">
                    <span class="btn btn-success saveformdata" 
                          data-redirect_url="<?php echo site_url('students'); ?>"
                          data-url="<?php echo site_url('students/save_new'); ?>">Save</span>
                    <a class="btn btn-danger" href="<?php echo site_url('students'); ?>" >Cancel</a>
                </div>
            </div>
        </div>
    </div>
</div>


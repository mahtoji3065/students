<!DOCTYPE html>
<html>
    <head>
         <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>Report Card</title>
        <style>
            .center{
                text-align: center;
            }
            table, td, th {  
                border: 1px solid #ddd;
            }

            table {
                border-collapse: collapse;
                width: 100%;
            }

            th, td {
                padding: 10px;
            }
        </style>
    </head>
    <body>
        <table class="table report-table" style="margin-bottom: 0px;border: 1px solid lightgray;">
            <thead style="background: darkgray;">
                <tr>
                    <th>S.No.</th>
                    <th>Subject</th>
                    <th>Passing Marks</th>
                    <th>Total Marks</th>
                    <th>Obtained Marks</th>
                    <th>Grade</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $total_marks = 0;
                $total_passmarks = 0;
                if (!empty($subject_details)) {
                    $count = 1;
                    foreach ($subject_details as $row) {
                        $total_marks = $total_marks + $row->total_marks;
                        $total_passmarks = $total_passmarks + $row->pass_marks;
                        ?>
                        <tr >
                            <td class="center"><?php echo $count++; ?></td>
                            <td><?php echo $row->name; ?></td>
                            <td class="center"><?php echo $row->pass_marks; ?></td>
                            <td class="center"><?php echo $row->total_marks; ?></td>
                            <td class="center"><?php echo $row->obtained_marks; ?></td>
                            <td class="center"><strong><?php echo $row->grade; ?></strong></td>
                        </tr>
                        <?php
                    }
                }
                ?>                                           
            </tbody>
            <tfoot style="background: darkgray;">
                <tr>
                    <th colspan="2" style="text-align: right">Total</th>
                    <th><?php echo $total_passmarks; ?></th>
                    <th ><?php echo $total_marks; ?></th>
                    <th ><?php echo $student_details[0]->total_obtained_marks; ?></th>
                    <th ><?php echo $student_details[0]->result_class; ?></th>
                </tr>
            </tfoot>
        </table>
    </body>
</html>
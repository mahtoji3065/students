<div class="col-md-4 col-md-offset-4" style="margin-top: 10%;">
    <div class="panel panel-primary">        
        <div class="panel-body">
            <h4 class="text-primary text-center">Sign-Up</h4>
            <form id="signupform" action="javascript::;">
                <div class="row form-group">
                    <label class=" col-md-4 control-label">Username</label>
                    <div class="col-md-8">
                        <input type="text" class="form-control" name="user" />
                    </div>
                </div>
                <div class="row form-group">
                    <label class=" col-md-4 control-label">Password</label>
                    <div class="col-md-8">
                        <input type="password" class="form-control" name="password" />
                    </div>
                </div>
                <button class="btn-success">Sign-Up</button>
                <a href="<?php echo site_url('login'); ?>" class="pull-right">Log-In</a>
            </form>
        </div>
    </div>
    <center><span class="text-danger" id="errordetails"></span></center>
</div>
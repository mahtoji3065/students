<div class="col-md-4 col-md-offset-4" style="margin-top: 10%;">
    <div class="panel panel-primary">        
        <div class="panel-body">
            <h4 class="text-primary text-center">Log-In</h4>
            <form id="loginform" action="javascript::;">
                <div class="row form-group">
                    <div class="col-md-12">
                        <input type="text" class="form-control" placeholder="Username" name="user" />
                    </div>
                </div>
                <div class="row form-group">
                    <div class="col-md-12">
                        <input type="password" class="form-control" placeholder="Password"  name="password" />
                    </div>
                </div>               
                <button class="btn-success">Log-In</button>                 
                <a href="<?php echo site_url('login/sign_up'); ?>" class="pull-right">Sign-Up</a>                 
            </form>
        </div>
    </div>
    <center><span class="text-danger" id="errordetails"></span></center>
</div>

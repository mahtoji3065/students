<!DOCTYPE html>
<html lang="en">
    <head>
        <title> <?php echo $title; ?> | Test</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/plugin/bootstrap/css/bootstrap.min.css">   
        <script src="<?php echo base_url(); ?>/plugin/jquery.min.js"></script>
        <link rel="stylesheet" href="<?php echo base_url(); ?>/plugin/sweetalert/sweet-alert.css">  
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/plugin/datatables/media/css/dataTables.bootstrap.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>/plugin/datatables/media/css/dataTables.plugins.css">
        
        <style>
            input.parsley-success,
            select.parsley-success,
            textarea.parsley-success {
                border-color: #b2e600 !important;
            }


            input.parsley-error,
            select.parsley-error,
            textarea.parsley-error,
            .error-select,
            .checkbox-custom.parsley-error > i {
                border-color: #ff7b76 !important;
            }

            .parsley-errors-list {
                margin: 2px 0 3px;
                padding: 0;
                list-style-type: none;
                font-size: 12px;
                line-height: 0.9em;
                opacity: 0;
                color: #ff7b76 !important;
                transition: all 0.3s ease-in;
                -o-transition: all 0.3s ease-in;
                -moz-transition: all 0.3s ease-in;
                -webkit-transition: all 0.3s ease-in;
            }

            .parsley-errors-list.filled {
                opacity: 1;
                padding: 5px 0 10px;
                position: absolute
            }
        </style>
    </head>
    <body data-site-url="<?php echo site_url(); ?>">

        <div class="container" style="margin-top: 20px;">
            <?php echo $contents; ?>
        </div>
        <!--  PArsley  plugin -->
        <script src="<?php echo base_url(); ?>/plugin/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url(); ?>/plugin/parsley/parsley.min.js"></script>
        <script src="<?php echo base_url(); ?>/plugin/sweetalert/sweet-alert.min.js"></script>
        <script src="<?php echo base_url(); ?>/plugin/datatables/media/js/jquery.dataTables.js"></script>
        <script src="<?php echo base_url(); ?>/plugin/datatables/media/js/dataTables.bootstrap.js"></script>
        <?php echo $js; ?>
    </body>
</html>
